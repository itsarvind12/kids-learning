package com.example.alpha.kidslearningworld;

import android.app.Application;


/**
 * Created by ALPHA on 4/6/2017.
 */

public class Globalvar extends Application {
    String score;

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
